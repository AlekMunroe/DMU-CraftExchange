# DMU-CraftExchange
"CraftExchange"

<!-- ROADMAP -->
## Getting started

* Go into the /admin/db_connect.php file and input all your information
* Go to script.js and input your discord webhook URL under "webhookUrl"

* Go to URL/admin/register.php to create an admin account
* Delete URL/admin/register.php so others cannot sign up as an admin
* Go to URL/admin/admin-register.php to create employee accounts
* Go to /admin/database.php to create and edit the database